const hamburger = document.querySelector(".hamburger");
const navLinks = document.querySelector(".nav-links");
const links = document.querySelectorAll(".nav-links li");

hamburger.addEventListener('click', ()=>{
   //Animate Links
    navLinks.classList.toggle("open");
    links.forEach(link => {
        link.classList.toggle("fade");
    });

    //Hamburger Animation
    hamburger.classList.toggle("toggle");
});



$(".social-link").on("mouseover", function() {
    let data = $(this).attr("data-my-element");
    $(".social-text[data-my-element=" + data + "]").addClass("show");
  });
  
  $(".social-link").on("mouseout", function() {
    $(".social-text").removeClass("show");
  });
  